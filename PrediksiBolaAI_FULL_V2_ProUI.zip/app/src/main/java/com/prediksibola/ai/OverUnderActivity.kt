package com.prediksibola.ai

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.prediksibola.ai.databinding.ActivityOverunderBinding
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class OverUnderActivity : AppCompatActivity() {
    private lateinit var bind: ActivityOverunderBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind = ActivityOverunderBinding.inflate(layoutInflater)
        setContentView(bind.root)

        bind.btnOuPredict.setOnClickListener {
            val home = bind.ouHome.text.toString().trim()
            val away = bind.ouAway.text.toString().trim()
            if (home.isEmpty() || away.isEmpty()) {
                Toast.makeText(this, "Masukkan nama tim", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            // simulate analyze
            lifecycleScope.launch {
                bind.ouResult.text = "OVER 2.5 — Confidence 89%\nReason: Odds moved, xG high, shots avg high"
            }
        }
    }
}
