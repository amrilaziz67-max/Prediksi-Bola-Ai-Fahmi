package com.prediksibola.ai

import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {
    @POST("predict")
    suspend fun predict(@Body body: PredictRequest): PredictResponse

    @POST("predict_ou")
    suspend fun predictOU(@Body body: PredictRequest): OUPredictResponse
}
