package com.prediksibola.ai

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.prediksibola.ai.databinding.ActivityResultBinding
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ResultActivity : AppCompatActivity() {
    private lateinit var bind: ActivityResultBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind = ActivityResultBinding.inflate(layoutInflater)
        setContentView(bind.root)

        val home = intent.getStringExtra("home") ?: ""
        val away = intent.getStringExtra("away") ?: ""
        val oh = intent.getDoubleExtra("oh", 2.2)
        val od = intent.getDoubleExtra("od", 3.3)
        val oa = intent.getDoubleExtra("oa", 3.6)

        bind.tvMatch.text = "$home  vs  $away"

        // For demo: use simple async call to show result placeholder
        CoroutineScope(Dispatchers.Main).launch {
            bind.tvStatus.text = "Calculating predictions..."
            // In production call server or TFLite models
            withContext(Dispatchers.Default) {
                Thread.sleep(600) // simulate work
            }
            bind.tvFT.text = "FT Prediction:\nHome: 58%  Draw: 22%  Away: 20%"
            bind.tvOU.text = "O/U 2.5:\nOver: 67%  Under: 33%"
            bind.tvBTTS.text = "BTTS:\nYes: 72%  No: 28%"
            bind.tvHT.text = "HT Prediction:\nHome: 62% Draw: 20% Away: 18%"
            bind.tvScore.text = "Predicted Score:\n2 - 1"
            bind.tvStatus.text = "Done"
        }
    }
}
