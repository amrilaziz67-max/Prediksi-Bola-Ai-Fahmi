package com.prediksibola.ai

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.prediksibola.ai.databinding.ActivityMainBinding
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var bind: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind = ActivityMainBinding.inflate(layoutInflater)
        setContentView(bind.root)

        bind.btnPredict.setOnClickListener {
            val home = bind.inputHome.text.toString().trim()
            val away = bind.inputAway.text.toString().trim()
            val oh = bind.inputOddsHome.text.toString().toDoubleOrNull() ?: 2.2
            val od = bind.inputOddsDraw.text.toString().toDoubleOrNull() ?: 3.3
            val oa = bind.inputOddsAway.text.toString().toDoubleOrNull() ?: 3.6

            if (home.isEmpty() || away.isEmpty()) {
                Toast.makeText(this, "Isi nama tim terlebih dahulu", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Launch ResultActivity with extras
            val intent = Intent(this, ResultActivity::class.java)
            intent.putExtra("home", home)
            intent.putExtra("away", away)
            intent.putExtra("oh", oh)
            intent.putExtra("od", od)
            intent.putExtra("oa", oa)
            startActivity(intent)
        }

        bind.btnOuAnalyzer.setOnClickListener {
            startActivity(Intent(this, OverUnderActivity::class.java))
        }
    }
}
