package com.prediksibola.ai

data class PredictRequest(
    val home_team: String? = null,
    val away_team: String? = null,
    val odds_home: Double? = null,
    val odds_draw: Double? = null,
    val odds_away: Double? = null
)
