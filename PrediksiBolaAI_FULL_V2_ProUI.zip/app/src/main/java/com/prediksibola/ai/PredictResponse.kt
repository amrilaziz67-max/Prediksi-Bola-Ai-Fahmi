package com.prediksibola.ai

import java.io.Serializable

data class PredictResponse(val status:String?, val predictions: Predictions?) : Serializable
data class Predictions(val ft: FTResult?, val over25_prob: Double?, val bts_prob: Double?, val confidence: Double?) : Serializable
data class FTResult(val home: Double, val draw: Double, val away: Double) : Serializable

data class OUPredictResponse(val status: String?, val over25_prob: Double?, val reason: OUReason?, val confidence: Double?)
data class OUReason(val odds_open: Double?, val odds_close: Double?, val odds_movement: Double?, val predicted_xg: Double?, val shots_avg: Double?)
