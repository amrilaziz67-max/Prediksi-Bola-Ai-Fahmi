PrediksiBolaAI Pro - Full Project

How to use:
1. Open this project in Android Studio (File -> Open).
2. Replace assets/proxy_meta.tflite and assets/proxy_ou.tflite with your TFLite models.
3. Set BASE_URL in Network.kt to your server for online predictions.
4. Build -> Build APK(s) to generate installable APK.

Notes:
- This project includes professional white-blue UI (Theme).
- Offline TFLite inference expects inputs shaped as defined in ResultActivity and OverUnderActivity.
